from flask import Flask, render_template, request, redirect, url_for, session, flash, make_response
import sqlite3
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, date

app = Flask(__name__)
app.secret_key = "troca_esta_chave_por_uma_mesmo_forte"

DATABASE = "database.db"


def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            flash("Tens de iniciar sessão primeiro.")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function


def is_admin():
    return session.get("role") == "admin"


def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            flash("Tens de iniciar sessão primeiro.")
            return redirect(url_for("login"))
        if not is_admin():
            flash("Acesso reservado ao administrador.")
            return redirect(url_for("dashboard"))
        return f(*args, **kwargs)
    return decorated_function


def get_quartos_ordenados(db):
    return db.execute(
        """
        SELECT *
        FROM recursos
        ORDER BY CAST(REPLACE(nome, 'Quarto ', '') AS INTEGER)
        """
    ).fetchall()


@app.route("/")
def home():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/sobre")
@login_required
def sobre():
    return render_template("sobre.html")


@app.route("/contactos")
@login_required
def contactos():
    return render_template("contactos.html")


@app.route("/registo", methods=["GET", "POST"])
def registo():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "").strip()
        confirm_password = request.form.get("confirm_password", "").strip()

        if not username or not email or not password or not confirm_password:
            flash("Preenche todos os campos.")
            return render_template("registo.html")

        if password != confirm_password:
            flash("As palavras-passe não coincidem.")
            return render_template("registo.html")

        db = get_db()
        existing = db.execute(
            "SELECT * FROM users WHERE username = ? OR email = ?",
            (username, email)
        ).fetchone()

        if existing:
            db.close()
            flash("Username ou email já existente.")
            return render_template("registo.html")

        hashed_password = generate_password_hash(password)

        db.execute(
            """
            INSERT INTO users (username, email, password, role)
            VALUES (?, ?, ?, ?)
            """,
            (username, email, hashed_password, "user")
        )
        db.commit()
        db.close()

        flash("Conta criada com sucesso. Já podes iniciar sessão.")
        return redirect(url_for("login"))

    return render_template("registo.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))

    remembered_username = request.cookies.get("remembered_username", "")

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        lembrar = request.form.get("lembrar")

        if not username or not password:
            flash("Preenche todos os campos.")
            return render_template("login.html", remembered_username=username)

        db = get_db()
        user = db.execute(
            "SELECT * FROM users WHERE username = ?",
            (username,)
        ).fetchone()
        db.close()

        if user and check_password_hash(user["password"], password):
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["role"] = user["role"]

            response = make_response(redirect(url_for("dashboard")))

            if lembrar:
                response.set_cookie("remembered_username", username, max_age=60 * 60 * 24 * 30)
            else:
                response.set_cookie("remembered_username", "", expires=0)

            flash("Login efetuado com sucesso.")
            return response

        flash("Credenciais inválidas.")
        return render_template("login.html", remembered_username=username)

    return render_template("login.html", remembered_username=remembered_username)


@app.route("/logout")
def logout():
    session.clear()
    flash("Sessão terminada com sucesso.")
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html")


@app.route("/users")
@admin_required
def users():
    db = get_db()
    rows = db.execute("SELECT * FROM users ORDER BY id DESC").fetchall()
    db.close()
    return render_template("users.html", users=rows)


@app.route("/apagar-user/<int:user_id>")
@admin_required
def apagar_user(user_id):
    if user_id == session.get("user_id"):
        flash("Não podes apagar o teu próprio utilizador enquanto estás autenticado.")
        return redirect(url_for("users"))

    db = get_db()
    db.execute("DELETE FROM users WHERE id = ?", (user_id,))
    db.commit()
    db.close()
    flash("Utilizador apagado com sucesso.")
    return redirect(url_for("users"))


@app.route("/recursos")
@login_required
def recursos():
    db = get_db()
    rows = get_quartos_ordenados(db)
    db.close()
    return render_template("recursos.html", recursos=rows)


@app.route("/criar-recurso", methods=["GET", "POST"])
@admin_required
def criar_recurso():
    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        descricao = request.form.get("descricao", "").strip()

        if not nome:
            flash("O nome do quarto é obrigatório.")
            return render_template("criar_recurso.html")

        db = get_db()
        existe = db.execute("SELECT * FROM recursos WHERE nome = ?", (nome,)).fetchone()
        if existe:
            db.close()
            flash("Já existe um quarto com esse nome.")
            return render_template("criar_recurso.html")

        db.execute(
            "INSERT INTO recursos (nome, descricao) VALUES (?, ?)",
            (nome, descricao)
        )
        db.commit()
        db.close()

        flash("Quarto criado com sucesso.")
        return redirect(url_for("recursos"))

    return render_template("criar_recurso.html")


@app.route("/editar-recurso/<int:recurso_id>", methods=["GET", "POST"])
@admin_required
def editar_recurso(recurso_id):
    db = get_db()
    recurso = db.execute("SELECT * FROM recursos WHERE id = ?", (recurso_id,)).fetchone()

    if not recurso:
        db.close()
        flash("Quarto não encontrado.")
        return redirect(url_for("recursos"))

    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        descricao = request.form.get("descricao", "").strip()

        if not nome:
            db.close()
            flash("O nome do quarto é obrigatório.")
            return redirect(url_for("editar_recurso", recurso_id=recurso_id))

        existe = db.execute(
            "SELECT * FROM recursos WHERE nome = ? AND id != ?",
            (nome, recurso_id)
        ).fetchone()

        if existe:
            db.close()
            flash("Já existe outro quarto com esse nome.")
            return redirect(url_for("editar_recurso", recurso_id=recurso_id))

        db.execute(
            "UPDATE recursos SET nome = ?, descricao = ? WHERE id = ?",
            (nome, descricao, recurso_id)
        )
        db.commit()
        db.close()
        flash("Quarto atualizado com sucesso.")
        return redirect(url_for("recursos"))

    db.close()
    return render_template("editar_recurso.html", recurso=recurso)


@app.route("/apagar-recurso/<int:recurso_id>")
@admin_required
def apagar_recurso(recurso_id):
    db = get_db()

    reserva_associada = db.execute(
        "SELECT * FROM reservas WHERE recurso_id = ?",
        (recurso_id,)
    ).fetchone()

    if reserva_associada:
        db.close()
        flash("Não podes apagar um quarto que já tenha reservas.")
        return redirect(url_for("recursos"))

    db.execute("DELETE FROM recursos WHERE id = ?", (recurso_id,))
    db.commit()
    db.close()
    flash("Quarto apagado com sucesso.")
    return redirect(url_for("recursos"))


@app.route("/reservas")
@login_required
def reservas():
    recurso_id = request.args.get("recurso_id", "").strip()
    data_filtro = request.args.get("data", "").strip()

    query = """
    SELECT reservas.*, recursos.nome AS recurso_nome, users.username AS user_nome
    FROM reservas
    JOIN recursos ON reservas.recurso_id = recursos.id
    JOIN users ON reservas.user_id = users.id
    WHERE 1=1
    """
    params = []

    if not is_admin():
        query += " AND reservas.user_id = ?"
        params.append(session["user_id"])

    if recurso_id:
        query += " AND reservas.recurso_id = ?"
        params.append(recurso_id)

    if data_filtro:
        query += " AND reservas.data = ?"
        params.append(data_filtro)

    query += " ORDER BY reservas.data, reservas.hora"

    db = get_db()
    rows = db.execute(query, params).fetchall()
    quartos = get_quartos_ordenados(db)
    db.close()

    return render_template(
        "reservas.html",
        reservas=rows,
        recursos=quartos,
        filtro_recurso_id=recurso_id,
        filtro_data=data_filtro
    )


@app.route("/criar-reserva", methods=["GET", "POST"])
@login_required
def criar_reserva():
    db = get_db()
    quartos = get_quartos_ordenados(db)

    if request.method == "POST":
        recurso_id = request.form.get("recurso_id", "").strip()
        data_reserva = request.form.get("data", "").strip()
        hora = request.form.get("hora", "").strip()
        observacoes = request.form.get("observacoes", "").strip()

        if not recurso_id or not data_reserva or not hora:
            db.close()
            flash("Preenche quarto, data e hora.")
            return render_template("criar_reserva.html", recursos=quartos)

        try:
            data_obj = datetime.strptime(data_reserva, "%Y-%m-%d").date()
            if data_obj < date.today():
                db.close()
                flash("Não podes criar reservas no passado.")
                return render_template("criar_reserva.html", recursos=quartos)
        except ValueError:
            db.close()
            flash("Data inválida.")
            return render_template("criar_reserva.html", recursos=quartos)

        conflito = db.execute(
            """
            SELECT * FROM reservas
            WHERE recurso_id = ? AND data = ? AND hora = ?
            """,
            (recurso_id, data_reserva, hora)
        ).fetchone()

        if conflito:
            db.close()
            flash("Já existe uma reserva para esse quarto nessa data e hora.")
            return render_template("criar_reserva.html", recursos=quartos)

        db.execute(
            """
            INSERT INTO reservas (user_id, recurso_id, data, hora, observacoes)
            VALUES (?, ?, ?, ?, ?)
            """,
            (session["user_id"], recurso_id, data_reserva, hora, observacoes)
        )
        db.commit()
        db.close()
        flash("Reserva criada com sucesso.")
        return redirect(url_for("reservas"))

    db.close()
    return render_template("criar_reserva.html", recursos=quartos)


@app.route("/editar-reserva/<int:reserva_id>", methods=["GET", "POST"])
@login_required
def editar_reserva(reserva_id):
    db = get_db()

    if is_admin():
        reserva = db.execute(
            "SELECT * FROM reservas WHERE id = ?",
            (reserva_id,)
        ).fetchone()
    else:
        reserva = db.execute(
            "SELECT * FROM reservas WHERE id = ? AND user_id = ?",
            (reserva_id, session["user_id"])
        ).fetchone()

    if not reserva:
        db.close()
        flash("Reserva não encontrada ou sem permissão.")
        return redirect(url_for("reservas"))

    quartos = get_quartos_ordenados(db)

    if request.method == "POST":
        recurso_id = request.form.get("recurso_id", "").strip()
        data_reserva = request.form.get("data", "").strip()
        hora = request.form.get("hora", "").strip()
        observacoes = request.form.get("observacoes", "").strip()

        if not recurso_id or not data_reserva or not hora:
            db.close()
            flash("Preenche quarto, data e hora.")
            return redirect(url_for("editar_reserva", reserva_id=reserva_id))

        try:
            data_obj = datetime.strptime(data_reserva, "%Y-%m-%d").date()
            if data_obj < date.today():
                db.close()
                flash("Não podes definir reservas no passado.")
                return redirect(url_for("editar_reserva", reserva_id=reserva_id))
        except ValueError:
            db.close()
            flash("Data inválida.")
            return redirect(url_for("editar_reserva", reserva_id=reserva_id))

        conflito = db.execute(
            """
            SELECT * FROM reservas
            WHERE recurso_id = ? AND data = ? AND hora = ? AND id != ?
            """,
            (recurso_id, data_reserva, hora, reserva_id)
        ).fetchone()

        if conflito:
            db.close()
            flash("Já existe outra reserva para esse quarto nessa data e hora.")
            return redirect(url_for("editar_reserva", reserva_id=reserva_id))

        db.execute(
            """
            UPDATE reservas
            SET recurso_id = ?, data = ?, hora = ?, observacoes = ?
            WHERE id = ?
            """,
            (recurso_id, data_reserva, hora, observacoes, reserva_id)
        )
        db.commit()
        db.close()
        flash("Reserva atualizada com sucesso.")
        return redirect(url_for("reservas"))

    db.close()
    return render_template("editar_reserva.html", reserva=reserva, recursos=quartos)


@app.route("/apagar-reserva/<int:reserva_id>")
@login_required
def apagar_reserva(reserva_id):
    db = get_db()

    if is_admin():
        reserva = db.execute("SELECT * FROM reservas WHERE id = ?", (reserva_id,)).fetchone()
    else:
        reserva = db.execute(
            "SELECT * FROM reservas WHERE id = ? AND user_id = ?",
            (reserva_id, session["user_id"])
        ).fetchone()

    if not reserva:
        db.close()
        flash("Reserva não encontrada ou sem permissão.")
        return redirect(url_for("reservas"))

    db.execute("DELETE FROM reservas WHERE id = ?", (reserva_id,))
    db.commit()
    db.close()
    flash("Reserva apagada com sucesso.")
    return redirect(url_for("reservas"))


@app.route("/relatorio-recurso")
@login_required
def relatorio_recurso():
    recurso_id = request.args.get("recurso_id", "").strip()

    db = get_db()
    quartos = get_quartos_ordenados(db)

    reservas_quarto = []
    if recurso_id:
        query = """
        SELECT reservas.*, recursos.nome AS recurso_nome, users.username AS user_nome
        FROM reservas
        JOIN recursos ON reservas.recurso_id = recursos.id
        JOIN users ON reservas.user_id = users.id
        WHERE reservas.recurso_id = ?
        """
        params = [recurso_id]

        if not is_admin():
            query += " AND reservas.user_id = ?"
            params.append(session["user_id"])

        query += " ORDER BY reservas.data, reservas.hora"

        reservas_quarto = db.execute(query, params).fetchall()

    db.close()

    return render_template(
        "relatorio_recurso.html",
        reservas=reservas_quarto,
        recursos=quartos,
        filtro_recurso_id=recurso_id
    )


@app.route("/relatorio-data")
@login_required
def relatorio_data():
    data_filtro = request.args.get("data", "").strip()

    query = """
    SELECT reservas.*, recursos.nome AS recurso_nome, users.username AS user_nome
    FROM reservas
    JOIN recursos ON reservas.recurso_id = recursos.id
    JOIN users ON reservas.user_id = users.id
    WHERE 1=1
    """
    params = []

    if not is_admin():
        query += " AND reservas.user_id = ?"
        params.append(session["user_id"])

    if data_filtro:
        query += " AND reservas.data = ?"
        params.append(data_filtro)

    query += " ORDER BY reservas.hora"

    db = get_db()
    rows = db.execute(query, params).fetchall()
    db.close()

    return render_template("relatorio_data.html", reservas=rows, filtro_data=data_filtro)


@app.route("/relatorio-minhas")
@login_required
def relatorio_minhas():
    db = get_db()
    rows = db.execute(
        """
        SELECT reservas.*, recursos.nome AS recurso_nome
        FROM reservas
        JOIN recursos ON reservas.recurso_id = recursos.id
        WHERE reservas.user_id = ?
        ORDER BY reservas.data, reservas.hora
        """,
        (session["user_id"],)
    ).fetchall()
    db.close()
    return render_template("relatorio_minhas.html", reservas=rows)


if __name__ == "__main__":
    app.run(debug=True)