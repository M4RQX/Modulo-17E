import sqlite3
from werkzeug.security import generate_password_hash

conn = sqlite3.connect("database.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user'
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS recursos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT UNIQUE NOT NULL,
    descricao TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS reservas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    recurso_id INTEGER NOT NULL,
    data TEXT NOT NULL,
    hora TEXT NOT NULL,
    observacoes TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (recurso_id) REFERENCES recursos(id)
)
""")

admin = cursor.execute("SELECT * FROM users WHERE username = 'admin'").fetchone()
if not admin:
    cursor.execute("""
    INSERT INTO users (username, email, password, role)
    VALUES (?, ?, ?, ?)
    """, (
        "admin",
        "admin@hotelaria.com",
        generate_password_hash("1234"),
        "admin"
    ))

quartos = []

for piso in [100, 200, 300, 400]:
    for numero in range(0, 13):
        quarto_num = piso + numero

        if quarto_num in [100, 200, 300, 400]:
            descricao = "Quarto individual"
        elif quarto_num in [101, 201, 301, 401]:
            descricao = "Quarto duplo"
        elif quarto_num in [102, 202, 302, 402]:
            descricao = "Quarto twin"
        elif quarto_num in [103, 203, 303, 403]:
            descricao = "Quarto com varanda"
        elif quarto_num in [104, 204, 304, 404]:
            descricao = "Quarto standard"
        elif quarto_num in [105, 205, 305, 405]:
            descricao = "Quarto deluxe"
        elif quarto_num in [106, 206, 306, 406]:
            descricao = "Quarto com vista"
        elif quarto_num in [107, 207, 307, 407]:
            descricao = "Quarto familiar"
        elif quarto_num in [108, 208, 308, 408]:
            descricao = "Suite júnior"
        elif quarto_num in [109, 209, 309, 409]:
            descricao = "Suite executiva"
        elif quarto_num in [110, 210, 310, 410]:
            descricao = "Suite premium"
        elif quarto_num in [111, 211, 311, 411]:
            descricao = "Suite master"
        else:
            descricao = "Suite presidencial"

        quartos.append((f"Quarto {quarto_num}", descricao))

for nome, descricao in quartos:
    existe = cursor.execute("SELECT * FROM recursos WHERE nome = ?", (nome,)).fetchone()
    if not existe:
        cursor.execute(
            "INSERT INTO recursos (nome, descricao) VALUES (?, ?)",
            (nome, descricao)
        )

conn.commit()
conn.close()

print("Base de dados criada com sucesso.")
print("Login admin: admin / 1234")
print("Quartos criados: 100 a 112, 200 a 212, 300 a 312, 400 a 412")